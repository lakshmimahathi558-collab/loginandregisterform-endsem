
import { useState } from "react";

function App() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [user, setUser] = useState(null);

  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");

  const [message, setMessage] = useState("");
  const [success, setSuccess] = useState(false);

  function register(e) {
    e.preventDefault();

    setUser({ name, email, password });
    setMessage("Registration Successful!");
    setSuccess(true);

    setName("");
    setEmail("");
    setPassword("");
  }

  function login(e) {
    e.preventDefault();

    if (
      user &&
      loginEmail === user.email &&
      loginPassword === user.password
    ) {
      setMessage("Welcome " + user.name + "! Login Successful.");
      setSuccess(true);
    } else {
      setMessage("Invalid Email or Password!");
      setSuccess(false);
    }

    setLoginEmail("");
    setLoginPassword("");
  }

  const inputStyle = {
    width: "100%",
    padding: "12px",
    margin: "10px 0",
    boxSizing: "border-box",
    border: "1px solid #ccc",
    borderRadius: "6px",
    fontSize: "15px"
  };

  const buttonStyle = {
    width: "100%",
    padding: "12px",
    backgroundColor: "#2563eb",
    color: "white",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
    fontSize: "16px",
    fontWeight: "bold"
  };

  const cardStyle = {
    backgroundColor: "white",
    color: "#222",
    padding: "25px",
    borderRadius: "12px",
    width: "100%",
    maxWidth: "350px",
    boxShadow: "0 4px 15px rgba(0,0,0,0.12)"
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        backgroundColor: "#f1f5f9",
        fontFamily: "Arial",
        padding: "30px 15px",
        boxSizing: "border-box"
      }}
    >
      <h1 style={{ textAlign: "center", color: "#1e293b" }}>
        Login and Registration
      </h1>

      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "flex-start",
          gap: "25px",
          flexWrap: "wrap",
          marginTop: "35px"
        }}
      >
        {/* Registration Form */}
        <div style={cardStyle}>
          <h2 style={{ textAlign: "center" }}>
            Registration Form
          </h2>

          <form onSubmit={register}>
            <input
              style={inputStyle}
              type="text"
              placeholder="Enter Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />

            <input
              style={inputStyle}
              type="email"
              placeholder="Enter Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />

            <input
              style={inputStyle}
              type="password"
              placeholder="Enter Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />

            <button style={buttonStyle} type="submit">
              Register
            </button>
          </form>
        </div>

        {/* Login Form */}
        <div style={cardStyle}>
          <h2 style={{ textAlign: "center" }}>
            Login Form
          </h2>

          <form onSubmit={login}>
            <input
              style={inputStyle}
              type="email"
              placeholder="Login Email"
              value={loginEmail}
              onChange={(e) => setLoginEmail(e.target.value)}
              required
            />

            <input
              style={inputStyle}
              type="password"
              placeholder="Login Password"
              value={loginPassword}
              onChange={(e) => setLoginPassword(e.target.value)}
              required
            />

            <button style={buttonStyle} type="submit">
              Login
            </button>
          </form>
        </div>
      </div>

      {/* Message */}
      {message && (
        <h3
          style={{
            textAlign: "center",
            color: success ? "green" : "red",
            marginTop: "25px"
          }}
        >
          {message}
        </h3>
      )}

      {/* Registered Details */}
      {user && (
        <div
          style={{
            ...cardStyle,
            margin: "25px auto",
            textAlign: "center"
          }}
        >
          <h2>Registered Details</h2>
          <p>Name: {user.name}</p>
          <p>Email: {user.email}</p>
        </div>
      )}
    </div>
  );
}

export default App;
